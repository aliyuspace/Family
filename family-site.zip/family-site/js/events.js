// ============================================================
//  events.js — Family Events / Timeline page logic
// ============================================================

function renderEvents(filter) {
  const items = filter === 'All'
    ? EVENTS
    : EVENTS.filter(e => e.type === filter);

  const tl = document.getElementById('timeline');
  tl.innerHTML = items.length === 0
    ? `<p style="text-align:center;color:var(--muted);padding:40px 0;font-style:italic">No events in this category yet.</p>`
    : items.map(ev => `
        <div class="ev-block" data-type="${ev.type}">
          <div class="ev-dot"></div>
          <div class="ev-card">
            <img class="ev-img" src="${ev.photo}" alt="${ev.title}" loading="lazy"/>
            <div class="ev-body">
              <div class="ev-tags">
                <span class="ev-type-badge">${ev.type.toUpperCase()}</span>
                <span class="ev-date">${ev.date}</span>
              </div>
              <div class="ev-title">${ev.title}</div>
              <div class="ev-desc">${ev.desc}</div>
            </div>
          </div>
        </div>
      `).join('');

  document.getElementById('eventCount').textContent =
    items.length + ' event' + (items.length !== 1 ? 's' : '');
}

function setFilter(type, btn) {
  document.querySelectorAll('.flt-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  renderEvents(type);
}

// ── INIT ─────────────────────────────────────────────────────
renderEvents('All');
