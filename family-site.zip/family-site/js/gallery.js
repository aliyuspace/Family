// ============================================================
//  gallery.js — Family Gallery page logic
// ============================================================

let currentFilter = 'All';
let currentItems  = [];
let currentIndex  = 0;

// ── RENDER GRID ──────────────────────────────────────────────
function renderGallery(filter) {
  currentFilter = filter;
  currentItems  = filter === 'All'
    ? GALLERY
    : GALLERY.filter(g => g.type === filter);

  const grid = document.getElementById('galGrid');
  grid.innerHTML = currentItems.map((g, i) => `
    <div class="gal-item" onclick="openLightbox(${i})">
      <img src="${g.photo}" alt="${g.label}" loading="lazy"/>
      <div class="gal-label">
        <span class="gl-name">${g.label}</span>
        <span class="gl-type">${g.type}</span>
      </div>
    </div>
  `).join('');

  document.getElementById('photoCount').textContent =
    currentItems.length + ' photo' + (currentItems.length !== 1 ? 's' : '');
}

function setFilter(type, btn) {
  document.querySelectorAll('.flt-btn').forEach(b => b.classList.remove('on'));
  btn.classList.add('on');
  renderGallery(type);
}

// ── LIGHTBOX ─────────────────────────────────────────────────
function openLightbox(index) {
  currentIndex = index;
  showLightboxItem();
  document.getElementById('lightbox').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function showLightboxItem() {
  const g = currentItems[currentIndex];
  document.getElementById('lbImg').src     = g.photo;
  document.getElementById('lbImg').alt     = g.label;
  document.getElementById('lbCaption').textContent = g.label;
  document.getElementById('lbType').textContent    = g.type;

  // Set download link
  const dl = document.getElementById('lbDownload');
  dl.href     = g.photo;
  dl.download = (g.label || 'family-photo').replace(/\s+/g, '-').toLowerCase() + '.jpg';
}

function closeLightbox() {
  document.getElementById('lightbox').classList.add('hidden');
  document.body.style.overflow = '';
}

// Swipe support for lightbox
let lbTouchX = 0;
document.addEventListener('DOMContentLoaded', () => {
  const lb = document.getElementById('lightbox');
  lb.addEventListener('touchstart', e => {
    lbTouchX = e.touches[0].clientX;
  }, { passive: true });
  lb.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - lbTouchX;
    if (Math.abs(dx) > 50) {
      if (dx < 0 && currentIndex < currentItems.length - 1) {
        currentIndex++; showLightboxItem();
      } else if (dx > 0 && currentIndex > 0) {
        currentIndex--; showLightboxItem();
      }
    }
  }, { passive: true });

  // keyboard navigation
  document.addEventListener('keydown', e => {
    if (document.getElementById('lightbox').classList.contains('hidden')) return;
    if (e.key === 'ArrowRight' && currentIndex < currentItems.length - 1) {
      currentIndex++; showLightboxItem();
    } else if (e.key === 'ArrowLeft' && currentIndex > 0) {
      currentIndex--; showLightboxItem();
    } else if (e.key === 'Escape') {
      closeLightbox();
    }
  });
});

// ── INIT ─────────────────────────────────────────────────────
renderGallery('All');
