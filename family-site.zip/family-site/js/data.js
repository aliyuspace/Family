// ============================================================
//  FAMILY DATA — Edit this file to add/remove members & events
//  HOW TO ADD A MEMBER:
//    1. Add entry to MEMBERS object below
//    2. Add their id to their parent's childIds array
//    3. If married, set spouseId on both people
// ============================================================

const MEMBERS = {

  // ── GENERATION 1 ──────────────────────────────────────────
  harold: {
    name: "Harold",
    role: "Great-Grandfather",
    dob: "March 2, 1920",
    location: "Edinburgh, UK",
    status: "Deceased",
    phone: "—",
    occ: "Farmer",
    bio: "Harold was a hardy Scottish farmer who raised seven children. He lived to 98 and never missed a Sunday church service.",
    photo: "https://picsum.photos/seed/harold/400/400",
    spouseId: "dorothy",
    childIds: ["rufus", "victor", "antonio", "miriam"]
  },
  dorothy: {
    name: "Dorothy",
    role: "Great-Grandmother",
    dob: "July 10, 1924",
    location: "Edinburgh, UK",
    status: "Deceased",
    phone: "—",
    occ: "Seamstress",
    bio: "Dorothy was a gifted seamstress who made every child's school uniform by hand. Remembered for her warm laugh and shortbread.",
    photo: "https://picsum.photos/seed/dorothy/400/400",
    spouseId: "harold",
    childIds: ["rufus", "victor", "antonio", "miriam"]
  },

  // ── GENERATION 2 ──────────────────────────────────────────
  rufus: {
    name: "Rufus",
    role: "Grandfather",
    dob: "March 4, 1947",
    location: "Florence, Italy",
    status: "Married",
    phone: "+1 555 100-2001",
    occ: "Retired Architect",
    bio: "Rufus built the family home with his own hands. He teaches woodworking on Saturdays and tells the best stories at dinner.",
    photo: "https://picsum.photos/seed/rufus/400/400",
    spouseId: "kara",
    childIds: ["kate", "marco", "thomas"]
  },
  kara: {
    name: "Kara",
    role: "Grandmother",
    dob: "January 15, 1950",
    location: "Florence, Italy",
    status: "Married",
    phone: "+1 555 100-2000",
    occ: "Retired Teacher",
    bio: "Kara is the matriarch of the family, known for her incredible garden and famous Sunday roasts. She paints watercolors every morning.",
    photo: "https://picsum.photos/seed/kara/400/400",
    spouseId: "rufus",
    childIds: ["kate", "marco", "thomas"]
  },
  victor: {
    name: "Victor",
    role: "Great-Uncle",
    dob: "May 17, 1945",
    location: "Edinburgh, UK",
    status: "Widowed",
    phone: "+44 131 555 4400",
    occ: "Retired Journalist",
    bio: "Victor was a war correspondent for 30 years. Now retired, he writes memoirs and is the family's unofficial historian.",
    photo: "https://picsum.photos/seed/victor/400/400",
    spouseId: null,
    childIds: ["patrick"]
  },
  antonio: {
    name: "Antonio",
    role: "Great-Uncle",
    dob: "October 8, 1948",
    location: "Naples, Italy",
    status: "Married",
    phone: "+39 081 555 7701",
    occ: "Retired Police",
    bio: "Antonio served 30 years in the Carabinieri. He is now a local legend in his village.",
    photo: "https://picsum.photos/seed/antonio/400/400",
    spouseId: "rosa_s",
    childIds: ["nadia"]
  },
  rosa_s: {
    name: "Rosa",
    role: "Great-Aunt",
    dob: "July 4, 1952",
    location: "Naples, Italy",
    status: "Married",
    phone: "+39 081 555 7700",
    occ: "Retired Doctor",
    bio: "Rosa is a retired paediatrician who spent 35 years in Naples hospitals. She now grows vegetables and spoils her grandchildren.",
    photo: "https://picsum.photos/seed/rosas/400/400",
    spouseId: "antonio",
    childIds: ["nadia"]
  },
  miriam: {
    name: "Miriam",
    role: "Great-Aunt",
    dob: "September 9, 1955",
    location: "Paris, France",
    status: "Divorced",
    phone: "+33 1 555 8800",
    occ: "Chef",
    bio: "Miriam ran a celebrated brasserie in Paris for 20 years. She still cooks private dinners and teaches classes.",
    photo: "https://picsum.photos/seed/miriam/400/400",
    spouseId: null,
    childIds: ["claude_f"]
  },

  // ── GENERATION 3 ──────────────────────────────────────────
  kate: {
    name: "Kate",
    role: "Mother",
    dob: "June 22, 1975",
    location: "London, UK",
    status: "Married",
    phone: "+44 7911 123456",
    occ: "Pediatric Nurse",
    bio: "Kate is a dedicated pediatric nurse and weekend painter. She organizes all family reunions and always brings the best cake.",
    photo: "https://picsum.photos/seed/kate/400/400",
    spouseId: "sebastian",
    childIds: ["conner", "olivia_d", "liam"]
  },
  sebastian: {
    name: "Sebastian",
    role: "Father",
    dob: "September 10, 1973",
    location: "London, UK",
    status: "Married",
    phone: "+44 7911 654321",
    occ: "Chef & Restaurateur",
    bio: "Sebastian runs his own restaurant and coaches youth football. He is the undisputed family BBQ champion every summer.",
    photo: "https://picsum.photos/seed/sebastian/400/400",
    spouseId: "kate",
    childIds: ["conner", "olivia_d", "liam"]
  },
  marco: {
    name: "Marco",
    role: "Uncle",
    dob: "August 14, 1972",
    location: "Milan, Italy",
    status: "Married",
    phone: "+39 02 555 8800",
    occ: "Banker",
    bio: "Marco is a senior investment banker in Milan. Passionate about vintage cars — restores them in his garage on weekends.",
    photo: "https://picsum.photos/seed/marco/400/400",
    spouseId: "lucia",
    childIds: ["gianluca", "elena", "matteo", "chiara", "luca_m"]
  },
  lucia: {
    name: "Lucia",
    role: "Aunt",
    dob: "April 30, 1974",
    location: "Milan, Italy",
    status: "Married",
    phone: "+39 02 555 8801",
    occ: "Architect",
    bio: "Lucia is an award-winning architect. She designed the family's holiday villa in Tuscany and is working on a museum.",
    photo: "https://picsum.photos/seed/lucia/400/400",
    spouseId: "marco",
    childIds: ["gianluca", "elena", "matteo", "chiara", "luca_m"]
  },
  thomas: {
    name: "Thomas",
    role: "Uncle",
    dob: "December 12, 1968",
    location: "Glasgow, UK",
    status: "Married",
    phone: "+44 141 555 9900",
    occ: "Cardiologist",
    bio: "Thomas is a cardiologist in Glasgow who has won several medical awards. He runs marathons and mentors young doctors.",
    photo: "https://picsum.photos/seed/thomas/400/400",
    spouseId: "helen",
    childIds: ["angus", "isla", "callum", "niamh", "robbie"]
  },
  helen: {
    name: "Helen",
    role: "Aunt",
    dob: "March 3, 1970",
    location: "Glasgow, UK",
    status: "Married",
    phone: "+44 141 555 9901",
    occ: "Librarian",
    bio: "Helen runs the busiest public library in Glasgow. Avid reader, storyteller, and secret marathon runner.",
    photo: "https://picsum.photos/seed/helen/400/400",
    spouseId: "thomas",
    childIds: ["angus", "isla", "callum", "niamh", "robbie"]
  },
  patrick: {
    name: "Patrick",
    role: "Cousin",
    dob: "September 9, 1972",
    location: "Dublin, Ireland",
    status: "Married",
    phone: "+353 1 555 6600",
    occ: "Barrister",
    bio: "Patrick is a barrister in Dublin specializing in environmental law. Known for his booming laugh and terrible golf swing.",
    photo: "https://picsum.photos/seed/patrick/400/400",
    spouseId: "siobhan",
    childIds: ["declan", "aoife", "cormac", "maeve"]
  },
  siobhan: {
    name: "Siobhan",
    role: "Cousin-in-law",
    dob: "February 20, 1975",
    location: "Dublin, Ireland",
    status: "Married",
    phone: "+353 1 555 6601",
    occ: "Graphic Designer",
    bio: "Siobhan runs her own studio in Dublin. She designed the family Christmas cards for 15 years.",
    photo: "https://picsum.photos/seed/siobhan/400/400",
    spouseId: "patrick",
    childIds: ["declan", "aoife", "cormac", "maeve"]
  },
  nadia: {
    name: "Nadia",
    role: "Cousin",
    dob: "March 15, 1978",
    location: "Naples, Italy",
    status: "Married",
    phone: "+39 081 555 7702",
    occ: "Pharmacist",
    bio: "Nadia runs the family pharmacy in Naples that has served the neighborhood for three generations.",
    photo: "https://picsum.photos/seed/nadia/400/400",
    spouseId: "giuseppe",
    childIds: ["valeria", "enzo", "carmela", "salvatore"]
  },
  giuseppe: {
    name: "Giuseppe",
    role: "Cousin-in-law",
    dob: "November 2, 1975",
    location: "Naples, Italy",
    status: "Married",
    phone: "+39 081 555 7703",
    occ: "Michelin Chef",
    bio: "Giuseppe is a Michelin-starred chef in Naples. He and Sebastian have an annual cook-off the whole family bets on.",
    photo: "https://picsum.photos/seed/giuseppe/400/400",
    spouseId: "nadia",
    childIds: ["valeria", "enzo", "carmela", "salvatore"]
  },
  claude_f: {
    name: "Claude",
    role: "Cousin",
    dob: "April 25, 1980",
    location: "Paris, France",
    status: "Married",
    phone: "+33 6 555 8801",
    occ: "Film Director",
    bio: "Claude has directed two feature films that won awards at Cannes. Working on a documentary about the family's history.",
    photo: "https://picsum.photos/seed/claudef/400/400",
    spouseId: "ines",
    childIds: ["leo_f", "celeste", "hugo_f", "ambre"]
  },
  ines: {
    name: "Inès",
    role: "Cousin-in-law",
    dob: "July 30, 1983",
    location: "Paris, France",
    status: "Married",
    phone: "+33 6 555 8802",
    occ: "Actress",
    bio: "Inès is a stage actress and drama teacher. She played Juliet in a Paris production that ran for two years.",
    photo: "https://picsum.photos/seed/ines/400/400",
    spouseId: "claude_f",
    childIds: ["leo_f", "celeste", "hugo_f", "ambre"]
  },

  // ── GENERATION 4 ──────────────────────────────────────────
  conner: {
    name: "Conner",
    role: "Son",
    dob: "July 11, 2002",
    location: "London, UK",
    status: "Single",
    phone: "+44 7900 111222",
    occ: "CS Student",
    bio: "Conner studies computer science at UCL. Avid gamer, skateboarder, and secretly a very good cook.",
    photo: "https://picsum.photos/seed/conner/400/400",
    spouseId: null,
    childIds: ["conner_s"]
  },
  olivia_d: {
    name: "Olivia",
    role: "Daughter",
    dob: "April 5, 2005",
    location: "London, UK",
    status: "Single",
    phone: "+44 7900 333444",
    occ: "Student",
    bio: "Olivia loves art and contemporary dance. In secondary school and dreams of studying medicine one day.",
    photo: "https://picsum.photos/seed/oliviad/400/400",
    spouseId: null,
    childIds: []
  },
  liam: {
    name: "Liam",
    role: "Son",
    dob: "September 3, 2008",
    location: "London, UK",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Liam is 16, obsessed with football and robotics club. He has already built his first working robot.",
    photo: "https://picsum.photos/seed/liam/400/400",
    spouseId: null,
    childIds: []
  },
  gianluca: {
    name: "Gianluca",
    role: "Son",
    dob: "October 20, 1999",
    location: "Milan, Italy",
    status: "Single",
    phone: "+39 349 222 0001",
    occ: "Architecture Student",
    bio: "Gianluca studies architecture in Milan, following his mother's footsteps. Interns at her firm during summers.",
    photo: "https://picsum.photos/seed/gianluca/400/400",
    spouseId: null,
    childIds: []
  },
  elena: {
    name: "Elena",
    role: "Daughter",
    dob: "February 14, 2002",
    location: "Milan, Italy",
    status: "Single",
    phone: "+39 349 222 0002",
    occ: "Student",
    bio: "Elena studies fashion communication in Milan. She and her Aunt share a close bond over style and design.",
    photo: "https://picsum.photos/seed/elena/400/400",
    spouseId: null,
    childIds: []
  },
  matteo: {
    name: "Matteo",
    role: "Son",
    dob: "August 7, 2006",
    location: "Milan, Italy",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Matteo loves motorsport — dad takes him to every F1 race. He knows every car engine by sound.",
    photo: "https://picsum.photos/seed/matteo/400/400",
    spouseId: null,
    childIds: []
  },
  chiara: {
    name: "Chiara",
    role: "Daughter",
    dob: "March 19, 2009",
    location: "Milan, Italy",
    status: "Single",
    phone: "N/A",
    occ: "Schoolgirl",
    bio: "Chiara is a gifted violinist and top of her class in mathematics. Dreams of studying at MIT.",
    photo: "https://picsum.photos/seed/chiara/400/400",
    spouseId: null,
    childIds: []
  },
  luca_m: {
    name: "Luca",
    role: "Son",
    dob: "July 30, 2012",
    location: "Milan, Italy",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Luca loves video games and cooking. At 12, he won third place in a junior cooking competition.",
    photo: "https://picsum.photos/seed/lucam/400/400",
    spouseId: null,
    childIds: []
  },
  angus: {
    name: "Angus",
    role: "Son",
    dob: "January 25, 1998",
    location: "Glasgow, UK",
    status: "Married",
    phone: "+44 7720 555 001",
    occ: "Junior Doctor",
    bio: "Angus followed his father Thomas into medicine. Junior doctor at Glasgow Royal Infirmary.",
    photo: "https://picsum.photos/seed/angus/400/400",
    spouseId: "fiona_a",
    childIds: ["robyn", "ewan"]
  },
  fiona_a: {
    name: "Fiona",
    role: "Daughter-in-law",
    dob: "June 8, 2000",
    location: "Glasgow, UK",
    status: "Married",
    phone: "+44 7720 555 002",
    occ: "Nurse",
    bio: "Fiona is a nurse at the same hospital as Angus. They met during a shift and married three years later.",
    photo: "https://picsum.photos/seed/fiona/400/400",
    spouseId: "angus",
    childIds: ["robyn", "ewan"]
  },
  isla: {
    name: "Isla",
    role: "Daughter",
    dob: "March 7, 2001",
    location: "Edinburgh, UK",
    status: "Single",
    phone: "+44 7720 555 003",
    occ: "Teacher",
    bio: "Isla teaches primary school in Edinburgh. Passionate about early childhood literacy and writes children's books.",
    photo: "https://picsum.photos/seed/isla/400/400",
    spouseId: null,
    childIds: []
  },
  callum: {
    name: "Callum",
    role: "Son",
    dob: "September 14, 2004",
    location: "Glasgow, UK",
    status: "Single",
    phone: "+44 7720 555 004",
    occ: "Engineering Student",
    bio: "Callum studies mechanical engineering at Strathclyde. On the university rowing team with internship offers.",
    photo: "https://picsum.photos/seed/callum/400/400",
    spouseId: null,
    childIds: []
  },
  niamh: {
    name: "Niamh",
    role: "Daughter",
    dob: "December 5, 2007",
    location: "Glasgow, UK",
    status: "Single",
    phone: "N/A",
    occ: "Schoolgirl",
    bio: "Niamh is a talented artist. Her paintings have been shown in a local gallery. Hopes to study at art school.",
    photo: "https://picsum.photos/seed/niamh/400/400",
    spouseId: null,
    childIds: []
  },
  robbie: {
    name: "Robbie",
    role: "Son",
    dob: "April 22, 2010",
    location: "Glasgow, UK",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Robbie is the funniest person in every room. Loves comedy, magic tricks, and has his grandad's humor.",
    photo: "https://picsum.photos/seed/robbie/400/400",
    spouseId: null,
    childIds: []
  },
  declan: {
    name: "Declan",
    role: "2nd Cousin",
    dob: "August 12, 2001",
    location: "Dublin, Ireland",
    status: "Single",
    phone: "+353 87 555 0001",
    occ: "Music Producer",
    bio: "Declan is a music producer who has worked with several Irish artists. The coolest person at every gathering.",
    photo: "https://picsum.photos/seed/declan/400/400",
    spouseId: null,
    childIds: []
  },
  aoife: {
    name: "Aoife",
    role: "2nd Cousin",
    dob: "March 28, 2004",
    location: "Dublin, Ireland",
    status: "Single",
    phone: "+353 87 555 0002",
    occ: "Student",
    bio: "Aoife studies environmental science in Cork. Deeply passionate about climate activism. Cycles everywhere.",
    photo: "https://picsum.photos/seed/aoife/400/400",
    spouseId: null,
    childIds: []
  },
  cormac: {
    name: "Cormac",
    role: "2nd Cousin",
    dob: "June 5, 2008",
    location: "Dublin, Ireland",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Cormac is a gifted GAA hurling player. Scouted by the county team and hopes to go professional.",
    photo: "https://picsum.photos/seed/cormac/400/400",
    spouseId: null,
    childIds: []
  },
  maeve: {
    name: "Maeve",
    role: "2nd Cousin",
    dob: "January 14, 2012",
    location: "Dublin, Ireland",
    status: "Single",
    phone: "N/A",
    occ: "Schoolgirl",
    bio: "Maeve writes poetry. Her poem won a national children's writing competition last year.",
    photo: "https://picsum.photos/seed/maeve/400/400",
    spouseId: null,
    childIds: []
  },
  valeria: {
    name: "Valeria",
    role: "2nd Cousin",
    dob: "April 4, 2001",
    location: "Naples, Italy",
    status: "Single",
    phone: "+39 348 111 2200",
    occ: "Nurse",
    bio: "Valeria trained as a nurse and works in the same hospital where her mother Rosa once worked.",
    photo: "https://picsum.photos/seed/valeria/400/400",
    spouseId: null,
    childIds: []
  },
  enzo: {
    name: "Enzo",
    role: "2nd Cousin",
    dob: "August 22, 2004",
    location: "Naples, Italy",
    status: "Single",
    phone: "+39 348 111 2201",
    occ: "Student",
    bio: "Enzo studies marine biology in Naples. Spends every free weekend diving in the Mediterranean.",
    photo: "https://picsum.photos/seed/enzo/400/400",
    spouseId: null,
    childIds: []
  },
  carmela: {
    name: "Carmela",
    role: "2nd Cousin",
    dob: "February 7, 2007",
    location: "Naples, Italy",
    status: "Single",
    phone: "N/A",
    occ: "Student",
    bio: "Carmela is a gifted pianist studying at the Naples conservatory. Dreams of Carnegie Hall.",
    photo: "https://picsum.photos/seed/carmela/400/400",
    spouseId: null,
    childIds: []
  },
  salvatore: {
    name: "Salvatore",
    role: "2nd Cousin",
    dob: "October 30, 2010",
    location: "Naples, Italy",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Salvatore is already taller than everyone else. Plays basketball and wants to be an astronaut.",
    photo: "https://picsum.photos/seed/salvatore/400/400",
    spouseId: null,
    childIds: []
  },
  leo_f: {
    name: "Léo",
    role: "2nd Cousin",
    dob: "May 12, 2009",
    location: "Paris, France",
    status: "Single",
    phone: "N/A",
    occ: "Student",
    bio: "Léo is obsessed with cinema and already making short films on his phone. He and his dad argue about film theory at dinner.",
    photo: "https://picsum.photos/seed/leof/400/400",
    spouseId: null,
    childIds: []
  },
  celeste: {
    name: "Céleste",
    role: "2nd Cousin",
    dob: "August 4, 2012",
    location: "Paris, France",
    status: "Single",
    phone: "N/A",
    occ: "Schoolgirl",
    bio: "Céleste loves ballet and mathematics. Wants to become an aerospace engineer — or a prima ballerina. Both.",
    photo: "https://picsum.photos/seed/celeste/400/400",
    spouseId: null,
    childIds: []
  },
  hugo_f: {
    name: "Hugo",
    role: "2nd Cousin",
    dob: "February 22, 2016",
    location: "Paris, France",
    status: "Single",
    phone: "N/A",
    occ: "Schoolboy",
    bio: "Hugo is 8 and thinks he is 28. Gives very confident opinions on everything and reads encyclopedias for fun.",
    photo: "https://picsum.photos/seed/hugof/400/400",
    spouseId: null,
    childIds: []
  },
  ambre: {
    name: "Ambre",
    role: "2nd Cousin",
    dob: "November 11, 2019",
    location: "Paris, France",
    status: "Single",
    phone: "N/A",
    occ: "Kindergartener",
    bio: "Ambre is 5 and the family's little firecracker. Refuses to speak anything but French and demands croissants every morning.",
    photo: "https://picsum.photos/seed/ambre/400/400",
    spouseId: null,
    childIds: []
  },

  // ── GENERATION 5 ──────────────────────────────────────────
  conner_s: {
    name: "Conner Jr.",
    role: "Grandson",
    dob: "March 11, 2023",
    location: "London, UK",
    status: "Single",
    phone: "N/A",
    occ: "Toddler",
    bio: "Little Conner is 2 years old and already demanding to use dad's laptop. Loves toy cars and chasing the cat.",
    photo: "https://picsum.photos/seed/conners/400/400",
    spouseId: null,
    childIds: []
  },
  robyn: {
    name: "Robyn",
    role: "Granddaughter",
    dob: "October 2, 2022",
    location: "Glasgow, UK",
    status: "Single",
    phone: "N/A",
    occ: "Toddler",
    bio: "Robyn is 2 years old and has inherited her grandmother Helen's bright eyes. Everyone says she will be a reader too.",
    photo: "https://picsum.photos/seed/robyn/400/400",
    spouseId: null,
    childIds: []
  },
  ewan: {
    name: "Ewan",
    role: "Grandson",
    dob: "July 18, 2024",
    location: "Glasgow, UK",
    status: "Single",
    phone: "N/A",
    occ: "Baby",
    bio: "Ewan is the newest family member, born July 2024. Already adored by every cousin who visits.",
    photo: "https://picsum.photos/seed/ewan/400/400",
    spouseId: null,
    childIds: []
  }
};

// ============================================================
//  TREE STRUCTURE — defines the visual hierarchy
//  This matches the childIds in MEMBERS above
// ============================================================
const TREE_ROOT = {
  id: "harold",
  spouse: "dorothy",
  children: [
    {
      id: "rufus",
      spouse: "kara",
      children: [
        {
          id: "kate",
          spouse: "sebastian",
          children: [
            { id: "conner", children: [{ id: "conner_s" }] },
            { id: "olivia_d" },
            { id: "liam" }
          ]
        },
        {
          id: "marco",
          spouse: "lucia",
          children: [
            { id: "gianluca" },
            { id: "elena" },
            { id: "matteo" },
            { id: "chiara" },
            { id: "luca_m" }
          ]
        },
        {
          id: "thomas",
          spouse: "helen",
          children: [
            {
              id: "angus",
              spouse: "fiona_a",
              children: [{ id: "robyn" }, { id: "ewan" }]
            },
            { id: "isla" },
            { id: "callum" },
            { id: "niamh" },
            { id: "robbie" }
          ]
        }
      ]
    },
    {
      id: "victor",
      children: [
        {
          id: "patrick",
          spouse: "siobhan",
          children: [
            { id: "declan" },
            { id: "aoife" },
            { id: "cormac" },
            { id: "maeve" }
          ]
        }
      ]
    },
    {
      id: "antonio",
      spouse: "rosa_s",
      children: [
        {
          id: "nadia",
          spouse: "giuseppe",
          children: [
            { id: "valeria" },
            { id: "enzo" },
            { id: "carmela" },
            { id: "salvatore" }
          ]
        }
      ]
    },
    {
      id: "miriam",
      children: [
        {
          id: "claude_f",
          spouse: "ines",
          children: [
            { id: "leo_f" },
            { id: "celeste" },
            { id: "hugo_f" },
            { id: "ambre" }
          ]
        }
      ]
    }
  ]
};

// ============================================================
//  GALLERY — Add new photos here
//  type: "Portrait" | "Event"
// ============================================================
const GALLERY = [
  { type: "Portrait", label: "Kara",        photo: "https://picsum.photos/seed/kara/600/800" },
  { type: "Portrait", label: "Rufus",       photo: "https://picsum.photos/seed/rufus/600/800" },
  { type: "Event",    label: "Italy Wedding",photo: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=800&fit=crop" },
  { type: "Portrait", label: "Kate",        photo: "https://picsum.photos/seed/kate/600/800" },
  { type: "Event",    label: "Kara's 70th", photo: "https://images.unsplash.com/photo-1464349153735-7db50ed83c84?w=600&h=800&fit=crop" },
  { type: "Portrait", label: "Thomas",      photo: "https://picsum.photos/seed/thomas/600/800" },
  { type: "Event",    label: "Anniversary", photo: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=600&h=800&fit=crop" },
  { type: "Portrait", label: "Angus",       photo: "https://picsum.photos/seed/angus/600/800" },
  { type: "Event",    label: "Christmas 2023",photo:"https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=600&h=800&fit=crop" },
  { type: "Portrait", label: "Helen",       photo: "https://picsum.photos/seed/helen/600/800" },
  { type: "Event",    label: "Family Reunion",photo:"https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=800&fit=crop" },
  { type: "Portrait", label: "Isla",        photo: "https://picsum.photos/seed/isla/600/800" },
  { type: "Event",    label: "Angus Wedding",photo:"https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=600&h=800&fit=crop" },
  { type: "Portrait", label: "Marco",       photo: "https://picsum.photos/seed/marco/600/800" },
  { type: "Portrait", label: "Lucia",       photo: "https://picsum.photos/seed/lucia/600/800" },
  { type: "Portrait", label: "Conner",      photo: "https://picsum.photos/seed/conner/600/800" },
];

// ============================================================
//  EVENTS — Add new events here
//  type: "Wedding" | "Birthday" | "Anniversary" | "Reunion" | "Other"
// ============================================================
const EVENTS = [
  {
    type: "Wedding",
    date: "September 14, 2008",
    title: "Kate & Sebastian's Wedding",
    desc: "A beautiful church ceremony in London followed by a garden reception.",
    photo: "https://images.unsplash.com/photo-1519741497674-611481863552?w=600&h=400&fit=crop"
  },
  {
    type: "Birthday",
    date: "January 15, 2020",
    title: "Kara's 70th Birthday",
    desc: "A grand celebration with all the family. Held at the Florence villa.",
    photo: "https://images.unsplash.com/photo-1464349153735-7db50ed83c84?w=600&h=400&fit=crop"
  },
  {
    type: "Anniversary",
    date: "June 10, 2023",
    title: "Rufus & Kara's 50th Anniversary",
    desc: "Golden anniversary dinner with the whole family in Florence.",
    photo: "https://images.unsplash.com/photo-1551632436-cbf8dd35adfa?w=600&h=400&fit=crop"
  },
  {
    type: "Birthday",
    date: "July 11, 2022",
    title: "Conner's 20th Birthday",
    desc: "Backyard BBQ party with friends and cousins in London.",
    photo: "https://images.unsplash.com/photo-1530103862676-de8c9debad1d?w=600&h=400&fit=crop"
  },
  {
    type: "Wedding",
    date: "May 4, 2019",
    title: "Angus & Fiona's Wedding",
    desc: "A beautiful ceremony in Glasgow Cathedral, reception by the loch.",
    photo: "https://images.unsplash.com/photo-1537633552985-df8429e8048b?w=600&h=400&fit=crop"
  },
  {
    type: "Reunion",
    date: "August 20, 2022",
    title: "Summer Family Reunion",
    desc: "The whole family gathered at Marco & Lucia's Tuscan villa for a week.",
    photo: "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?w=600&h=400&fit=crop"
  },
  {
    type: "Birthday",
    date: "March 4, 2022",
    title: "Rufus Turns 75",
    desc: "A surprise dinner party organized by Kara. Rufus cried happy tears.",
    photo: "https://images.unsplash.com/photo-1528605248644-14dd04022da1?w=600&h=400&fit=crop"
  },
  {
    type: "Other",
    date: "December 25, 2023",
    title: "Christmas at the Florence Villa",
    desc: "30 family members gathered for Christmas. The biggest reunion in years.",
    photo: "https://images.unsplash.com/photo-1513885535751-8b9238bd345a?w=600&h=400&fit=crop"
  }
];
