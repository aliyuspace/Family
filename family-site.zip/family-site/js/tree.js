// ============================================================
//  tree.js — Family Tree page logic
// ============================================================

// ── RENDER TREE ──────────────────────────────────────────────
function cardHTML(id, hasKids) {
  const m = MEMBERS[id];
  if (!m) return `<div class="m-card"><div class="card-name">${id}</div></div>`;

  const kidBtn = hasKids
    ? `<button class="btn-child" id="chbtn_${id}" onclick="toggleChildren('${id}',event)">CHILD</button>`
    : '';

  return `
    <div class="m-card">
      <img class="card-photo" src="${m.photo}" alt="${m.name}" loading="lazy"/>
      <div class="card-name">${m.name}</div>
      <div class="card-role">${m.role}</div>
      <div class="card-btns">
        <button class="btn-det" onclick="openModal('${id}',event)">DETAILS</button>
        ${kidBtn}
      </div>
    </div>`;
}

function renderNode(node) {
  const m = MEMBERS[node.id];
  if (!m) return '';
  const hasKids = !!(node.children && node.children.length);
  let html = `<div class="t-col">`;

  /* couple or single */
  if (node.spouse && MEMBERS[node.spouse]) {
    html += `<div class="t-row">
      <div class="t-col">${cardHTML(node.id, hasKids)}</div>
      <div class="h-conn"></div>
      <div class="t-col">${cardHTML(node.spouse, false)}</div>
    </div>`;
  } else {
    html += cardHTML(node.id, hasKids);
  }

  /* children */
  if (hasKids) {
    const barW = Math.max(2, node.children.length - 1) * 128;
    html += `
      <div class="ch-section" id="sec_${node.id}">
        <div class="v-conn" style="height:22px"></div>
        <div class="h-bar" style="width:${barW}px"></div>
        <div class="ch-row">`;

    node.children.forEach((child, i) => {
      html += `<div class="t-col">
        <div class="v-conn" style="height:20px"></div>
        ${renderNode(child)}
      </div>`;
    });

    html += `</div></div>`;
  }

  html += `</div>`;
  return html;
}

function buildTree() {
  const root = document.getElementById('treeRoot');
  root.innerHTML = renderNode(TREE_ROOT);
  document.getElementById('memberCount').textContent =
    Object.keys(MEMBERS).length + ' members';
}

// ── SMART CHILD TOGGLE ───────────────────────────────────────
// Rule: opening node X closes ALL other currently open sections
// so only one branch is visible at a time — keeps space clean

const openIds = new Set();

function toggleChildren(id, e) {
  e && e.stopPropagation();
  const el = document.getElementById('sec_' + id);
  if (!el) return;

  const isOpen = el.classList.contains('open');

  if (isOpen) {
    // close this subtree
    collapseSubtree(id);
  } else {
    // close ALL other open sections first
    [...openIds].forEach(openId => {
      if (openId !== id) collapseSubtree(openId);
    });
    // open this section
    el.classList.add('open');
    openIds.add(id);
    const btn = document.getElementById('chbtn_' + id);
    if (btn) { btn.textContent = 'HIDE'; btn.classList.add('open'); }
  }
}

function collapseSubtree(id) {
  const el = document.getElementById('sec_' + id);
  if (!el) return;
  // recursively collapse any open children inside
  el.querySelectorAll('.ch-section.open').forEach(child => {
    const cid = child.id.replace('sec_', '');
    openIds.delete(cid);
    const btn = document.getElementById('chbtn_' + cid);
    if (btn) { btn.textContent = 'CHILD'; btn.classList.remove('open'); }
    child.classList.remove('open');
  });
  el.classList.remove('open');
  openIds.delete(id);
  const btn = document.getElementById('chbtn_' + id);
  if (btn) { btn.textContent = 'CHILD'; btn.classList.remove('open'); }
}

// ── PAN & PINCH-ZOOM ─────────────────────────────────────────
const canvas  = document.getElementById('canvas');
const wrap    = document.getElementById('treeWrap');
let tx = 30, ty = 20, scale = 0.72;
let isDragging = false, lastX = 0, lastY = 0;
let pinchDist0 = 0, scale0 = 1, pinchCx = 0, pinchCy = 0, tx0 = 0, ty0 = 0;
let touchCount = 0;

function applyTransform(animate) {
  wrap.style.transition = animate ? 'transform .28s ease' : 'none';
  wrap.style.transform = `translate(${tx}px,${ty}px) scale(${scale})`;
  document.getElementById('zLabel').textContent = Math.round(scale * 100) + '%';
}

function zoomBy(delta, cx, cy) {
  const rect = canvas.getBoundingClientRect();
  const px = cx ?? rect.width / 2;
  const py = cy ?? rect.height / 2;
  const newScale = Math.min(2.6, Math.max(0.18, scale + delta));
  const ratio = newScale / scale;
  tx = px - ratio * (px - tx);
  ty = py - ratio * (py - ty);
  scale = newScale;
  applyTransform(true);
}

function resetView() {
  tx = 30; ty = 20; scale = 0.72;
  applyTransform(true);
}

// Mouse
canvas.addEventListener('mousedown', e => {
  if (e.target.closest('button')) return;
  isDragging = true;
  lastX = e.clientX; lastY = e.clientY;
  canvas.classList.add('dragging');
});
window.addEventListener('mousemove', e => {
  if (!isDragging) return;
  tx += e.clientX - lastX;
  ty += e.clientY - lastY;
  lastX = e.clientX; lastY = e.clientY;
  applyTransform(false);
});
window.addEventListener('mouseup', () => {
  isDragging = false;
  canvas.classList.remove('dragging');
});

// Scroll wheel zoom
canvas.addEventListener('wheel', e => {
  e.preventDefault();
  const rect = canvas.getBoundingClientRect();
  zoomBy(e.deltaY > 0 ? -0.09 : 0.09,
    e.clientX - rect.left, e.clientY - rect.top);
}, { passive: false });

// Touch pan & pinch
canvas.addEventListener('touchstart', e => {
  touchCount = e.touches.length;
  if (e.target.closest('button')) return;
  if (e.touches.length === 1) {
    lastX = e.touches[0].clientX;
    lastY = e.touches[0].clientY;
  } else if (e.touches.length === 2) {
    pinchDist0 = Math.hypot(
      e.touches[0].clientX - e.touches[1].clientX,
      e.touches[0].clientY - e.touches[1].clientY
    );
    scale0 = scale; tx0 = tx; ty0 = ty;
    pinchCx = (e.touches[0].clientX + e.touches[1].clientX) / 2;
    pinchCy = (e.touches[0].clientY + e.touches[1].clientY) / 2;
  }
  e.preventDefault();
}, { passive: false });

canvas.addEventListener('touchmove', e => {
  e.preventDefault();
  if (e.touches.length === 1 && touchCount === 1) {
    const dx = e.touches[0].clientX - lastX;
    const dy = e.touches[0].clientY - lastY;
    lastX = e.touches[0].clientX;
    lastY = e.touches[0].clientY;
    tx += dx; ty += dy;
    applyTransform(false);
  } else if (e.touches.length === 2) {
    const dist = Math.hypot(
      e.touches[0].clientX - e.touches[1].clientX,
      e.touches[0].clientY - e.touches[1].clientY
    );
    const newScale = Math.min(2.6, Math.max(0.18, scale0 * (dist / pinchDist0)));
    const ratio = newScale / scale0;
    tx = pinchCx - ratio * (pinchCx - tx0);
    ty = pinchCy - ratio * (pinchCy - ty0);
    scale = newScale;
    applyTransform(false);
  }
}, { passive: false });

canvas.addEventListener('touchend', e => {
  touchCount = e.touches.length;
}, { passive: true });

// ── MODAL ────────────────────────────────────────────────────
function openModal(id, e) {
  e && e.stopPropagation();
  const m = MEMBERS[id];
  if (!m) return;

  document.getElementById('mPhoto').src     = m.photo;
  document.getElementById('mName').textContent  = m.name;
  document.getElementById('mRoleTag').textContent = m.role;
  document.getElementById('mDob').textContent   = m.dob;
  document.getElementById('mLoc').textContent   = m.location;
  document.getElementById('mStat').textContent  = m.status;
  document.getElementById('mOcc').textContent   = m.occ;
  document.getElementById('mBio').textContent   = m.bio;

  // Phone — tappable copy
  const phoneEl = document.getElementById('mPhone');
  phoneEl.textContent = m.phone;
  phoneEl.classList.remove('copied');
  phoneEl.dataset.phone = m.phone;

  document.getElementById('modalOverlay').classList.remove('hidden');
  document.body.style.overflow = 'hidden';
}

function closeModal() {
  document.getElementById('modalOverlay').classList.add('hidden');
  document.body.style.overflow = '';
}

function copyPhone() {
  const el = document.getElementById('mPhone');
  const phone = el.dataset.phone;
  if (!phone || phone === '—' || phone === 'N/A') return;
  navigator.clipboard.writeText(phone).then(() => {
    el.classList.add('copied');
    showToast('Phone number copied!');
    setTimeout(() => el.classList.remove('copied'), 2500);
  }).catch(() => {
    // fallback for older browsers
    const tmp = document.createElement('input');
    tmp.value = phone;
    document.body.appendChild(tmp);
    tmp.select(); document.execCommand('copy');
    document.body.removeChild(tmp);
    el.classList.add('copied');
    showToast('Phone number copied!');
    setTimeout(() => el.classList.remove('copied'), 2500);
  });
}

function showToast(msg) {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(t._timer);
  t._timer = setTimeout(() => t.classList.remove('show'), 2200);
}

// ── INIT ─────────────────────────────────────────────────────
buildTree();
applyTransform(false);
